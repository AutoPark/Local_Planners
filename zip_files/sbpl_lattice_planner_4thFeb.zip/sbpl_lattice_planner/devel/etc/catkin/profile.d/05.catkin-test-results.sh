# generated from catkin/cmake/env-hooks/05.catkin-test-results.sh.develspace.in

export CATKIN_TEST_RESULTS_DIR="/home/fahad/catkin_ws/devel/navigation_experimental-groovy-devel/sbpl_lattice_planner/test_results"
export ROS_TEST_RESULTS_DIR="$CATKIN_TEST_RESULTS_DIR"
