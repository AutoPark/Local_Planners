#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables
export CATKIN_TEST_RESULTS_DIR="/home/fahad/catkin_ws/devel/navigation_experimental-groovy-devel/sbpl_lattice_planner/test_results"
export ROS_TEST_RESULTS_DIR="/home/fahad/catkin_ws/devel/navigation_experimental-groovy-devel/sbpl_lattice_planner/test_results"

# modified environment variables
export CMAKE_PREFIX_PATH="/home/fahad/catkin_ws/devel/navigation_experimental-groovy-devel/sbpl_lattice_planner/devel:$CMAKE_PREFIX_PATH"
export CPATH="/home/fahad/catkin_ws/devel/navigation_experimental-groovy-devel/sbpl_lattice_planner/devel/include:$CPATH"
export LD_LIBRARY_PATH="/home/fahad/catkin_ws/devel/navigation_experimental-groovy-devel/sbpl_lattice_planner/devel/lib:$LD_LIBRARY_PATH"
export PATH="/home/fahad/catkin_ws/devel/navigation_experimental-groovy-devel/sbpl_lattice_planner/devel/bin:$PATH"
export PKG_CONFIG_PATH="/home/fahad/catkin_ws/devel/navigation_experimental-groovy-devel/sbpl_lattice_planner/devel/lib/pkgconfig:$PKG_CONFIG_PATH"
export PYTHONPATH="/home/fahad/catkin_ws/devel/navigation_experimental-groovy-devel/sbpl_lattice_planner/devel/lib/python2.7/dist-packages:$PYTHONPATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/fahad/catkin_ws/devel/navigation_experimental-groovy-devel/sbpl_lattice_planner/devel/share/common-lisp"
export ROS_PACKAGE_PATH="/home/fahad/catkin_ws/devel/navigation_experimental-groovy-devel/sbpl_lattice_planner:/opt/ros/groovy/share:/opt/ros/groovy/stacks"